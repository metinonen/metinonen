globalThis.ngJest = {
  testEnvironmentOptions: {
    errorOnUnknownElements: true,
    errorOnUnknownProperties: false,
  },
};
import 'jest-preset-angular/setup-jest';
