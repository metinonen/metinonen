using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Api.Controllers
{
  [ApiController]
  [Route("api")]
  public class WeatherForecastController : ControllerBase
  {
    private static readonly string[] Summaries = new[]
    {
      "Freezing",
      "Bracing",
      "Chilly",
      "Cool",
      "Mild",
      "Warm",
      "Balmy",
      "Hot",
      "Sweltering",
      "Scorching"
    };

    private readonly ILogger<WeatherForecastController> _logger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
      _logger = logger;
    }

    [HttpGet("weatherforecasts")]
    public IEnumerable<WeatherForecast> WeatherForecasts(int count = 10)
    {
      var rng = new Random();
      return Enumerable
        .Range(1, count)
        .Select(
          index =>
            new WeatherForecast
            {
              DateFormatted = DateTime.Now.AddDays(index).ToString("d"),
              TemperatureC = rng.Next(-20, 55),
              Summary = Summaries[rng.Next(Summaries.Length)]
            }
        );
    }

    [HttpGet("weatherforecastsplus")]
    [Authorize]
    public IEnumerable<WeatherForecast> WeatherForecastsPlus(int count = 10)
    {
      return WeatherForecasts(count);
    }

    public class WeatherForecast
    {
      public string Id
      {
        get { return Guid.NewGuid().ToString(); }
      }
      public string DateFormatted { get; set; }
      public int TemperatureC { get; set; }
      public string Summary { get; set; }

      public int TemperatureF
      {
        get { return 32 + (int)(TemperatureC / 0.5556); }
      }
    }
  }
}
