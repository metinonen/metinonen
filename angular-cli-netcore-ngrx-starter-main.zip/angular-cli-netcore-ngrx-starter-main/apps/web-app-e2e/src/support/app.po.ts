export const getGreeting = () => cy.get('h1');
export const getPageMarkdown = () => cy.get('[data-testid=page-markdown]');
